myApp.controller('pollController',['$scope','userFactory','$http','$location','$routeParams','$cookies',function($scope,userFactory,$http,$location,$routeParams,$cookies){

$scope.savePoll = function(user){
  console.log(user);
  $scope.newpoll.user = user;

  userFactory.addPoll($scope.newpoll,function(data){
    console.log("data from pollcontroller", data);
    if(!data.data.err){
    $location.url('/loggedin')
    $scope.newpoll = {};
  }
  else if(data.data.msg){

    $scope.optmsg = data.data.msg
  }
  else{
    $scope.quesmsg = data.data.err.errors.question.message;
  }
  })
}

userFactory.showPolls(function(polls){
  console.log("from polls controller getting all topics", polls);
  $scope.polls = polls


})

$scope.deletePoll = function(poll){
  console.log("id of the poll", poll);
  userFactory.deletePoll(poll,function(data){
    userFactory.showPolls(function(polls){
      console.log("from polls controller getting all topics", polls);
      $scope.polls = polls


    })

  })
}



}]);
